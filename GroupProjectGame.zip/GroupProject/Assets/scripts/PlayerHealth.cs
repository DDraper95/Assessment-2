﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlayerHealth : MonoBehaviour
{
	string[] negativeHealth = {"Virus download - check that the website if legit before downloading",
		"Phishing email - check the url on the email", "DDoS (distributed denial-of-service)",
		"Deleted system 32", "Gave your bank details to a nigerian prince"};
	
	string[] positiveHealth = {"Virus scan","Installed Antivirus software",
		"Turned on the firewall","Checked a sites reputation","Scanned files before opening them"};
	
	string[] lowerSanity = {"Cyber bullying","Internet troll","You mum was Insulted",
		"Internet idiots"};
	
	string[] boostSanity = {"Cat videos","Watched a Youtube video","Chat with friends",
		"Skype call","Gaming"};

	public int startingHealth = 100;                            // The amount of health the player starts the game with.
	public static int currentHealth;                                   // The current health the player has.
	public int startingSanity = 100;
	public static int currentSanity;

	int randomNumber;

	// 200x300 px window will apear in the center of the screen.
	private Rect windowRect = new Rect ((Screen.width - 200)/2, (Screen.height - 300)/2, 200, 300);
	// Only show it if needed.
	private bool show = false;

	public Slider healthSlider;                                // Reference to the UI's health bar.
	public Slider sanitySlider;

	public string boxMessage;
	public string boxTitle;

	public Image damageImage;                                   // Reference to an image to flash on the screen on being hurt.
	public Image sanityImage;
	//public AudioClip deathClip;                                 // The audio clip to play when the player dies.
	public float flashSpeed = 5f;                               // The speed the damageImage will fade at.
	public Color damageColour = new Color(1f, 0f, 0f, 0.1f);    // The colour the damageImage is set to, to flash.
	public Color sanityColour = new Color (0f, 1f, 0f, 0.1f);

	public Vector3 previousPosition;

	//Animator anim;                                              // Reference to the Animator component.
	AudioSource playerAudio;                                    // Reference to the AudioSource component.
	//PlayerMovement playerMovement;                              // Reference to the player's movement.
	//PlayerShooting playerShooting;                              // Reference to the PlayerShooting script.
	public static bool isDead = false;                                                // Whether the player is dead.
	bool damaged;                                              // True when the player gets damaged.
	bool healed;
	
	void Awake ()
	{
		// Setting up the references.
		//anim = GetComponent <Animator> ();
		playerAudio = GetComponent <AudioSource> ();
		//playerMovement = GetComponent <PlayerMovement> ();
		//playerShooting = GetComponentInChildren <PlayerShooting> ();


		// Set the initial health of the player.
		currentHealth = startingHealth;
		currentSanity = startingSanity;
	}
	
	void Update ()
	{
		for (int i =1; i < 20; i++) {
						if (spawnDamageToHealth.allPositions[i] == transform.position) {
								TakeDamage (damagePlayer.damageToHealth);
								scoreManager.score -= 15;
								playerAudio.Play ();
								randomNumber = Random.Range( 0,negativeHealth.Length);
								boxTitle = "Damage to health";
								boxMessage = negativeHealth[randomNumber];
								show= true;
								transform.position = transform.position - new Vector3 (0, 1, 0);
						}
				}
		for (int i2 = 1; i2 <10; i2++) {
			if (spawnIncreaseHealth.increaseHealthPositions[i2] == transform.position) {
								healthBoost (increaseHealth.healthBonus);
								playerAudio.Play ();
								randomNumber = Random.Range (0,positiveHealth.Length);
				boxTitle = "Health Increase";
				boxMessage = positiveHealth[randomNumber];
				show = true;
								transform.position = transform.position - new Vector3 (0, 1, 0);
						}
				}
		for (int i3 = 1; i3 < 10; i3++) {
			if (spawnIncreaseSanity.increaseSanityPositions[i3] == transform.position) {
								sanityBoost (increaseSanity.sanityBonus);
								playerAudio.Play ();
								randomNumber = Random.Range (0,boostSanity.Length);
				boxTitle = "Sanity Increase";
				boxMessage = boostSanity[randomNumber];
				show = true;
								transform.position = transform.position - new Vector3 (0, 1, 0);
						}
				}
		for (int i4 = 1; i4 < 20; i4++) {
			if (spawnNegativeSanity.negativeSanityPositions[i4] == transform.position) {
								damageSanity (decreaseSanity.damageToSanity);
								playerAudio.Play ();
								scoreManager.score -= 15;
								randomNumber = Random.Range (0,lowerSanity.Length);
				boxTitle = "Sanity Decrease";
				boxMessage = lowerSanity[randomNumber];
				show = true;
								transform.position = transform.position - new Vector3 (0, 1, 0);
						}
				}
		if (mailObjective.myLocation == transform.position) {
			transform.position = transform.position - new Vector3(0,1,0);
		}
		// If the player has just been damaged...
		if(damaged)
		{
			// ... set the colour of the damageImage to the flash colour.
			damageImage.color = damageColour;
		}

		if (healed) {
			damageImage.color = sanityColour;
				}
		// Otherwise...
		else
		{
			// ... transition the colour back to clear.
		damageImage.color = Color.Lerp (damageImage.color, Color.clear, flashSpeed * Time.deltaTime);
		}
		
		// Reset the damaged flag.
		damaged = false;
		healed = false;
	}
	
	
	public void TakeDamage (int amount)
	{
		// Set the damaged flag so the screen will flash.
		damaged = true;
		
		// Reduce the current health by the damage amount.
		currentHealth -= amount;
		// Set the health bar's value to the current health.
		healthSlider.value = currentHealth;
		
		// Play the hurt sound effect.
		//playerAudio.Play ();
		
		// If the player has lost all it's health and the death flag hasn't been set yet...
		if(currentHealth <= 0 && !isDead)
		{
			// ... it should die.
			Death ();
		}
		//previousPosition = transform.position;
	}

	public void damageSanity (int damageToSanity)
	{
		// Set the damaged flag so the screen will flash.
		damaged = true;
		
		// Reduce the current health by the damage amount.
		currentSanity -= damageToSanity;
		// Set the health bar's value to the current health.
		sanitySlider.value = currentSanity;
		
		// Play the hurt sound effect.
		//playerAudio.Play ();
		
		// If the player has lost all it's health and the death flag hasn't been set yet...
		if(currentSanity <= 0 && !isDead)
		{
			// ... it should die.
			Death ();
		}
		//previousPosition = transform.position;
	}

	public void healthBoost (int healthBonus)
	{
		// Set the damaged flag so the screen will flash.
		healed = true;
		
		// Reduce the current health by the damage amount.
		if (currentHealth < 100) {
					currentHealth += healthBonus;
				}
		// Set the health bar's value to the current health.
		healthSlider.value = currentHealth;
		
		// Play the hurt sound effect.
		//playerAudio.Play ();
	}
	public void sanityBoost (int sanityBonus)
	{
		// Set the damaged flag so the screen will flash.
		healed = true;
		
		// Reduce the current health by the damage amount.
		if (currentSanity < 100) {
			currentSanity += sanityBonus;
		}
		// Set the health bar's value to the current health.
		sanitySlider.value = currentSanity;
		
		// Play the hurt sound effect.
		//playerAudio.Play ();
	}
	
	
	public static void Death ()
	{
		// Set the death flag so this function won't be called again.
		isDead = true;
				
		// Set the audiosource to play the death clip and play it (this will stop the hurt sound from playing).
		//playerAudio.clip = deathClip;
		//playerAudio.Play ();
	} 

	void OnGUI () 
	{
		if(show)
			windowRect = GUI.Window (0, windowRect, DialogWindow, boxTitle);
	}
	
	// This is the actual window.
	void DialogWindow (int windowID)
	{
		float y = 20;
		GUI.Label(new Rect(5,y, windowRect.width, 20), boxMessage);
		
		if(GUI.Button(new Rect(5,50, windowRect.width - 10, 20), "Okay"))
		{
			show = false;
		}

}
}
