﻿using UnityEngine;
using System.Collections;

public class spawnIncreaseHealth : MonoBehaviour {

	// Use this for initialization
	public Transform increaseHealthSpawn;
	public Vector3 myPosition;
	public static Vector3[] increaseHealthPositions = new Vector3[10];

	void Start () {
		int xAxis;
		int yAxis;


		for(int i = 1; i < 11; i++) {
			Transform increaseHealth;
			xAxis = Random.Range(-15, 15);
			yAxis = Random.Range (-15, 15);
			myPosition = new Vector3(xAxis + 0.5f, yAxis + 0.5f, 0);
			increaseHealth = Instantiate(increaseHealthSpawn, myPosition, Quaternion.identity) as Transform;
			increaseHealthPositions[i] = myPosition;
			}
		}
	}
