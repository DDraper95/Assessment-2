﻿using UnityEngine;
using System.Collections;

public class bankObjective : MonoBehaviour {
	
	public static Vector3 myLocation;
	int hitObjective =0;
	
	// Use this for initialization
	void Start () {
		myLocation = new Vector3(0,0,0);
		renderer.enabled = true;
	}
	
	// Update is called once per frame
	void Update () {
		myLocation = transform.position;
		if (playerScript.playerPosition == myLocation && hitObjective == 0 ) {
			scoreManager.score += 50;
			objectiveManager.objectives += 1;
			hitObjective =1;
			renderer.enabled = false;
		}
	}
}
