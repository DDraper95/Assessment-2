﻿using UnityEngine;
using System.Collections;

public class spawnNegativeSanity : MonoBehaviour {
	
	// Use this for initialization
	public Transform decreaseSanitySpawn;
	public Vector3 myPosition;
	public static Vector3[] negativeSanityPositions = new Vector3[20];
	
	void Start () {
		int xAxis;
		int yAxis;
		
		for(int i = 1; i < 21; i++) {
			Transform decreaseSanity;
			xAxis = Random.Range(-15, 15);
			yAxis = Random.Range (-15, 15);
			myPosition = new Vector3(xAxis + 0.5f, yAxis + 0.5f, 0);
			decreaseSanity = Instantiate(decreaseSanitySpawn, myPosition, Quaternion.identity) as Transform;
			negativeSanityPositions[i] = myPosition;
		}
	}
}
