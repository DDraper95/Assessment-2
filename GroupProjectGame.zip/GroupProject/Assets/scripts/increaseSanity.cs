﻿using UnityEngine;
using System.Collections;

public class increaseSanity : MonoBehaviour {
	
	public static int sanityBonus = 10;
	public static Vector3 myLocation;
	
	// Use this for initialization
	void Start () {
		myLocation = new Vector3(0,0,0);
	}
	
	// Update is called once per frame
	void Update () {
		myLocation = transform.position;
	}
}
