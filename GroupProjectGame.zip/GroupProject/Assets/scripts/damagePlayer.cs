﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class damagePlayer : MonoBehaviour {

	public static int damageToHealth = 25;
	public static Vector3 myLocation;
	
	// Use this for initialization
	void Start () {
		myLocation = new Vector3(0,0,0);
	}
	
	// Update is called once per frame
	void Update () {
	}
}
