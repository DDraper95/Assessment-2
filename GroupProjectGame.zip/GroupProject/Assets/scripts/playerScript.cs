﻿using UnityEngine;
using System.Collections;

public class playerScript : MonoBehaviour {


	public Vector3 vertical = new Vector3(0,0.1f,0);
	public Vector3 horizontal = new Vector3(0.1f,0,0);
	public static Vector3 playerPosition;

	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (!PlayerHealth.isDead) {
						playerMovement ();
						playerPosition = transform.position;
				}
	}
	void playerMovement() {
		if (Input.GetKeyDown ("w")) 
		{
			transform.Translate (vertical);
			scoreManager.score += 10;
		}
		if (Input.GetKeyDown ("s")) 
		{
			transform.Translate (-vertical);
			scoreManager.score += 10;
		}
		if (Input.GetKeyDown ("a")) 
		{
			transform.Translate (-horizontal);
			scoreManager.score += 10;
		}
		if (Input.GetKeyDown ("d")) 
		{
			transform.Translate (horizontal);
			scoreManager.score += 10;
		}
		if (Input.GetKeyDown ("escape")) {
			Application.LoadLevel(0);
				}
	}
}