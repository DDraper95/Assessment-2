﻿using UnityEngine;
using System.Collections;

public class spawnDamageToHealth : MonoBehaviour {
	// Use this for initialization
	public Transform damageHealthSpawn;
	public Vector3 myPosition;
	public static Vector3[] allPositions = new Vector3[20];
	
	void Start () {
		int xAxis;
		int yAxis;

		
		for(int i = 1; i < 21; i++) {
			Transform damageHealth;
			xAxis = Random.Range(-15, 15);
			yAxis = Random.Range (-15, 15);
			myPosition = new Vector3(xAxis + 0.5f, yAxis + 0.5f, 0);
			damageHealth = Instantiate(damageHealthSpawn, myPosition, Quaternion.identity) as Transform;
			allPositions[i] = myPosition;
		}
	}
}
