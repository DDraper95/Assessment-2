﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class gameOverManager : MonoBehaviour {

	public string boxTitle;
	public string boxMessage;
	private Rect windowRect = new Rect ((Screen.width - 200)/2, (Screen.height - 300)/2, 200, 300);
	bool show = false;
	Text text;                      // Reference to the Text component.

	void Awake ()
	{
		// Set up the reference.
		text = GetComponent <Text> ();
		text.text = "";

	}

	
	void Update ()
	{
		// Set the displayed text to be the word "Score" followed by the score value.
		if (objectiveManager.objectives == 3) {
			boxTitle = "Game Won!";
			boxMessage = "Well done you managed to conquer the Internet!";
			show = true;
			PlayerHealth.isDead	= false;
			Application.LoadLevel(0);
				}
		if (PlayerHealth.currentHealth == 0 || PlayerHealth.currentSanity == 0) {
			boxTitle = "Game Over!";
			boxMessage = "Unlcky the intenet has defeated you!!";
			show = true;
			PlayerHealth.isDead	= false;
			Application.LoadLevel(0);
				}
	}
	void OnGUI () 
	{
		if(show)
			windowRect = GUI.Window (0, windowRect, DialogWindow, boxTitle);
	}
	
	// This is the actual window.
	void DialogWindow (int windowID)
	{
		float y = 20;
		GUI.Label(new Rect(5,y, windowRect.width, 20), boxMessage);
		
		if(GUI.Button(new Rect(5,50, windowRect.width - 10, 20), "Okay"))
		{
			show = false;
		}
		
	}
}
