﻿using UnityEngine;
using System.Collections;

public class decreaseSanity : MonoBehaviour {

	public static int damageToSanity = 25;
	public static Vector3 myLocation;
	
	// Use this for initialization
	void Start () {
		myLocation = new Vector3(0,0,0);
	}
	
	// Update is called once per frame
	void Update () {
		myLocation = transform.position;
	}
}
