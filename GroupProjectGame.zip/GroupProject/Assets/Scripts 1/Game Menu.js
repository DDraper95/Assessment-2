var isQuit=false;
var isDatabase=false;

function OnMouseEnter(){
	//change text color
	GetComponent.<Renderer>().material.color=Color.red;
}

function OnMouseExit(){
	//change text color
	GetComponent.<Renderer>().material.color=Color.white;
}

function OnMouseUp(){
	//is this quit
	if (isQuit==true) {
		//quit the game
		Application.Quit();
	}
	else if (isDatabase==true){
	Application.OpenURL("https://docs.google.com/document/d/1RfVoH2gv93dsK75ZlwjYlUt5BX8nCQBkWh4psr6KYSE/edit");
	}
	
	else {
		//load level
		Application.LoadLevel(1);
	}
}

function Update(){
	//quit game if escape key is pressed
	if (Input.GetKey(KeyCode.Escape)) {
    		Application.Quit();
	}
}